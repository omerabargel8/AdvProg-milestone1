//
// Created by omer on 22/12/2019.
//
#include "VarDeclarationCmd.h"

//map of variables that updates the server(the simulator)
extern map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
extern map<string, VarDeclarationCmd> updateVarFromServer;

//this class implement the Command interface of type VarDeclarationCmd

//this function checks the "direction" of the update
//and puts the variable into the appropriate map
int VarDeclarationCmd::execute(int index) {
    this->varName = lexer[index+1];
    if (lexer[index+2] == "->") {
        this->simPointer = lexer[index+4];
        updateVarToServer.emplace(varName, *this);
    } else if (lexer[index+2] == "<-"){
        this->simPointer = lexer[index+4];
        updateVarFromServer.emplace(varName, *this);
    } else {
        this->value = expInterpret(lexer[index+3]);
        this->simPointer = "";
        updateVarFromServer.emplace(varName, *this);
        return 4;
    }
    return 5;
}

//updates the value
void VarDeclarationCmd::updateValue(double val) {
    this->value = val;
}

//returns the sim
string VarDeclarationCmd::getSim() {
    return this->simPointer;
}

//returns the value
double VarDeclarationCmd::getValue() {
    return this->value;
}
//receives string, interpret and calculate the expression
double VarDeclarationCmd::expInterpret(string exp) {
    //Interpreter i;
    string exp1 = expLexer(exp);
    Expression *ex =  i.interpret(exp1);
    return ex->calculate();
}

//this method recieves a string of expression and make a new string to interpret,
//replace all variable names that saves in one of the two maps with the variables values
string VarDeclarationCmd::expLexer(string exp) {
    string holder = "";
    string expression = "";
    string val = "";
    for (unsigned int j = 0; j<exp.length(); j++) {
        if(exp[j] == '*' || exp[j] == '/' || exp[j] == '+' || exp[j] == '-'|| exp[j] == '(' || exp[j] == ')') {
            if(holder != "") {
                //if holder is a variable name the we save in one of two maps
                if (updateVarToServer.count(holder) > 0) {
                    val = to_string(updateVarToServer[holder].getValue());
                    expression += val;
                } else if (updateVarFromServer.count(holder) > 0){
                    val = to_string(updateVarFromServer[holder].getValue());
                    expression += val;
                } else {
                    expression += holder;
                }
                holder = "";
            }
            expression += exp[j];
        } else if (exp[j] == ' '){
            if (holder != "") {
                //if holder is a variable name the we save in one of two maps
                if (updateVarToServer.count(holder) > 0) {
                    val = to_string(updateVarToServer[holder].getValue());
                    expression += val;
                } else if (updateVarFromServer.count(holder) > 0){
                    val = to_string(updateVarFromServer[holder].getValue());
                    expression += val;
                } else {
                    expression += holder;
                }
                holder = "";
            }

        } else {
            holder += exp[j];
        }
    }
    if (holder != "") {
        //if holder is a variable name the we save in one of two maps
        if (updateVarToServer.count(holder) > 0) {
            val = to_string(updateVarToServer[holder].getValue());
            expression += val;
        } else if (updateVarFromServer.count(holder) > 0){
            val = to_string(updateVarFromServer[holder].getValue());
            expression += val;
        } else {
            expression += holder;
            holder = "";
        }
    }
    return expression;
}