//
// Created by omer on 30/12/2019.
//

#ifndef EX_3_PRINTCMD_H
#define EX_3_PRINTCMD_H


#include "Command.h"
#include "VarDeclarationCmd.h"

//map of variables that updates the server(the simulator)
extern map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
extern map<string, VarDeclarationCmd> updateVarFromServer;

//this class implement the Command interface of type Print
class PrintCmd: public Command {
public:
    int execute(int index);
};


#endif //EX_3_PRINTCMD_H
