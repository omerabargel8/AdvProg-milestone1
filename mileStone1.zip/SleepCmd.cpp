//
// Created by omer on 22/12/2019.
//

#include "SleepCmd.h"
#include <thread>

//this class implement the Command interface of type condition (if/while)

//this method causes the main thread to sleep
int SleepCmd::execute(int index) {
    this_thread::sleep_for(chrono::milliseconds((int)i.expInterpret(lexer[index+1])));
    return 2;
}