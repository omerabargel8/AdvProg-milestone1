#include "OpenDataServerCmd.h"
#include "ConnectControlClientCmd.h"
#include "VarDeclarationCmd.h"
#include "UpdateVarCmd.h"
#include "SleepCmd.h"
#include "ConditionCmd.h"
#include "Command.h"
#include "PrintCmd.h"

//map of variables that updates the server(the simulator)
map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
map<string, VarDeclarationCmd> updateVarFromServer;
//map that maps between string to the matching command object
map<string, Command*> commandDefiner;
//queue of flight commands that we need to send to the simulator
queue <string> commandsToServer;
//the flag is on as long as we have not print "done"
bool doneFlag;
//vector of the code that is broken into strings
vector<string> lexer;
mutex mutexLock;
void defineCommandDefiner();
void parser();
int main(int argc, char *argv[]) {
    if(argc == 1) {
        cout<<"No arguments were passed"<<endl;
    } else {
        doneFlag = true;
        Lexer flightInstructionsReader = Lexer(argv[1]);
        lexer = flightInstructionsReader.lex();
        parser();
    }
    return 0;
}

//this method will go over all the strings in the array (almost all of them),
//create a Command object and run his execute action
void parser() {
    defineCommandDefiner();
    unsigned int i = 0;
    while (i < lexer.size()) {
        if (commandDefiner.count(lexer[i]) > 0) {
            Command *c = commandDefiner[lexer[i]];
            i += c->execute(i);
        } else{
            Command *c = new UpdateVarCmd();
            i += c->execute(i);
        }
    }
}

//this method initialize the commandDefiner map,
//key = string that describes the command, value =  the command object
void defineCommandDefiner() {
    commandDefiner["openDataServer"] = new OpenDataServerCmd();
    commandDefiner["connectControlClient"] = new ConnectControlClientCmd();
    commandDefiner["Print"] = new PrintCmd();
    commandDefiner["var"] = new VarDeclarationCmd();
    commandDefiner["Sleep"] = new SleepCmd();
    commandDefiner["while"] = new ConditionCmd();
    commandDefiner["if"] = new ConditionCmd();
}