//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_OPENDATASERVERCMD_H
#define EX_3_OPENDATASERVERCMD_H
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <thread>
#include <map>
#include <unordered_map>
#include <string>
#include "Command.h"
#include "VarDeclarationCmd.h"

//map of variables that updates the server(the simulator)
extern map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
extern map<string, VarDeclarationCmd> updateVarFromServer;
using namespace std;

//this class implement the Command interface of type OpenDataServer
//open a Server socket and wait for connection from the simulator
//the simulator sends a list of values ​​to this server 10 times a second
//the server store them in a data structure
class OpenDataServerCmd: public Command {
private:
    int port;
    unordered_map <string,double> xmlVars;
    map <int, string> xmlOrder;
    //we create VarDeclarationCmd object because we want to use his expInterpret method
    VarDeclarationCmd i;
public:
    void openDataServer();
    int execute(int index);
    void mapDefiner();
    void updateMap(string buffer);
    void updateVals(string sim, double value);
};


#endif //EX_3_OPENDATASERVERCMD_H
