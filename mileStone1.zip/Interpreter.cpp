//
// Created by omer on 14/11/2019.
//

#include "Interpreter.h"
#include <list>
#include <stack>
#include <map>
#include <queue>
#include <regex>

bool isDigit(char a) {
    if (a- '0' >= 0 && a - '0' <= 9) {
        return true;
    }
    return false;
}
bool isOperator(char a) {
    if (a == '+' || a == '-' || a == '*' || a == '/' || a == '(' || a == ')') {
        return true;
    }
    return false;
}
int priorities (char ops) {
    if (ops == '+' || ops == '-') {
        return 1;
    } else if (ops == '*' || ops == '/') {
        return 2;
    }
    return -1;
}
bool checkName(string str) {
    regex r("^[a-zA-z][\\w]*");
    return (regex_match(str, r));
}
bool checkVariableStr(string str) {
    regex r("([\\w]+[=][\\w | /.]+[/;])*([\\w]+[=][\\w |/.]+){0,1}");
    return (regex_match(str, r));
}
Expression* createExp(Expression* exp1, Expression* exp2, char ops) {
    switch (ops) {
        case '+':
            return new Plus(exp1, exp2);
            break;
        case '-':
            return new Minus(exp1,exp2);
            break;
        case '*':
            return new Mul(exp1,exp2);
            break;
        case '/':
            return new Div(exp1,exp2);
            break;
        case '&':
            return new UPlus(exp1);
            break;
        case '#':
            return new UMinus(exp1);
            break;
    }
    return NULL;
}
queue<string> Interpreter:: splitAndAssign(string expStr) {
    queue<string> exp;
    string var;
    unsigned int j;
    for (unsigned int i = 0; i< expStr.length(); i++) {
        if (isOperator(expStr[i])) {
            exp.push(expStr.substr(i, 1));
        } else {
            j = i;
            while (!isOperator(expStr[j]) && j < expStr.length()) {
                j++;
            }
            var = expStr.substr(i, j - i);
            if(variables.count(var)) {
                string val = variables.find(var)->second;
                if(val[0] == '-') {
                    exp.push("(");//im case of x+-3
                    exp.push("-");
                    exp.push(val.substr(1, val.length()-1));
                    exp.push(")");
                } else {
                    exp.push(variables.find(var)->second);
                }
            } else {
                exp.push(var);
            }
            if (j < expStr.length()) {
                exp.push(expStr.substr(j, 1));
            }
            i = j;
        }
    }
    return exp;
}
Expression* Interpreter:: interpret(string expStr) {
    queue<string> exp = splitAndAssign(expStr);
    stack<Expression*> expressions;
    stack<char> operators;
    string previous;
    while (!exp.empty()) {
        if (exp.front().compare(0,1,"(") == 0) {
            operators.push('(');
            previous = exp.front();
            exp.pop();
        } else if (isdigit(exp.front()[0])) {
            expressions.push(new Value(stod(exp.front())));
            previous = exp.front();
            exp.pop();
        } else if ((exp.front().compare(0,1,")") == 0)) {
            while ((operators.top() != '(') && !operators.empty()) {
                Expression* exp1 = expressions.top();
                expressions.pop();
                char ops = operators.top();
                operators.pop();
                if(ops == '#' || ops == '&') {
                    expressions.push(createExp(exp1, nullptr, ops));

                } else {
                    Expression *exp2 = expressions.top();
                    expressions.pop();
                    expressions.push(createExp(exp1, exp2, ops));
                }
            }
            if (!operators.empty()) {
                operators.pop();
            }
            previous = exp.front();
            exp.pop();
        } else if ((exp.front().compare(0,1,"+") == 0 || exp.front().compare(0,1,"-") == 0 )&& !isDigit(previous[0])) {
            if(exp.front().compare(0,1,"+") == 0) {
                operators.push('&');
            } else {
                operators.push('#');
            }
            previous = exp.front();
            exp.pop();
        } else if (isOperator(exp.front()[0])) {
            while (!operators.empty() && priorities(operators.top()) >= priorities(exp.front()[0]) && operators.top() != '(') {
                Expression *exp1 = expressions.top();
                expressions.pop();
                if (!expressions.empty()) {
                    Expression *exp2 = expressions.top();
                    expressions.pop();
                    char ops = operators.top();
                    operators.pop();
                    expressions.push(createExp(exp1, exp2, ops));
                } else {
                    expressions.push(exp1);
                    break;
                }
            }
            operators.push(exp.front()[0]);
            previous = exp.front();
            exp.pop();
        }
    }
    while (!operators.empty()) {
        Expression* exp1 = expressions.top();
        expressions.pop();
        char ops = operators.top();
        if(!expressions.empty()) {
            Expression *exp2 = expressions.top();
            expressions.pop();
            expressions.push(createExp(exp1, exp2, ops));
        } else{
            expressions.push(createExp(exp1, nullptr, ops));
        }
        operators.pop();
    }
    return expressions.top();
}
void Interpreter::setVariables(string varStr) {
    if(!checkVariableStr(varStr)) {
        throw "illegal variable assignment!";
    }
    string var;
    string delimiter = ";";
    string name;
    string value;
    while (varStr.length() != 0) {
        var = varStr.substr(0, varStr.find(delimiter));
        name = var.substr(0, var.find("="));
        if (!checkName(name)) {
            throw "illegal variable name";
        }
        value = var.substr(var.find("=") + 1, var.length() - 1);
        if (!variables.count(name)) {
            variables.insert(pair<string, string>(name, value));
        } else {
            variables.find(name)->second = value;
        }
        if (varStr[varStr.find(delimiter)] == ';') {
            varStr.erase(0, varStr.find(delimiter) + delimiter.length());
        } else {
            //int iff = varStr.length();
            //int p = var.length();
            varStr.clear();
        }
    }
    this->variables = variables;
}
