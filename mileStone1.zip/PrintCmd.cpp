//
// Created by omer on 30/12/2019.
//
#include "PrintCmd.h"

//this class implement the Command interface of type Print

int PrintCmd::execute(int index) {
    //checks if the string we received is a variable name(print his value)
    if (updateVarToServer.count(lexer[index+1]) > 0) {
        cout<<updateVarToServer[lexer[index+1]].getValue()<<endl;
    } else if (updateVarFromServer.count(lexer[index+1])>0){
        cout<<updateVarFromServer[lexer[index+1]].getValue()<<endl;
    } else {
        cout<<lexer[index+1] << endl;
    }
    return 2;
}
