//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_SLEEPCMD_H
#define EX_3_SLEEPCMD_H

#include "Command.h"
#include <unistd.h>
#include "VarDeclarationCmd.h"

//this class implement the Command interface of type condition (if/while)
class SleepCmd: public Command {
    //we create VarDeclarationCmd object because we want to use his expInterpret method
    VarDeclarationCmd i;
public:
    int execute(int index);
};


#endif //EX_3_SLEEPCMD_H
