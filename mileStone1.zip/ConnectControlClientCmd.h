//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_CONNECTCONTROLCLIENTCMD_H
#define EX_3_CONNECTCONTROLCLIENTCMD_H
#include "Command.h"
#include "VarDeclarationCmd.h"
#include <thread>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstring>
using namespace std;
//this class implement the Command interface of type ConnectControlClientCmd
//opens a client socket and connect the simulator as a client to send him flight commands
class ConnectControlClientCmd: public Command {
private:
    string ip;
    int port;
    //we create VarDeclarationCmd object because we want to use his expInterpret method
    VarDeclarationCmd i;
public:
    int execute(int index);
    void openControlClient();
};


#endif //EX_3_CONNECTCONTROLCLIENTCMD_H
