//
// Created by omer on 22/12/2019.
//

#include "UpdateVarCmd.h"

//this class implement the Command interface of type UpdateVar

int UpdateVarCmd::execute(int index) {
    this->varName = lexer[index];
    this->value = i.expInterpret(lexer[index+2]);
    cout<<"interpreter"<<this->value<<endl;
    //update the value of the variable at the updateVarToServer map
    updateVarToServer.at(varName).updateValue(value);
    //creates a command to send the simulator and puts her to the command queue
    string setCommand = "set "+ updateVarToServer.at(varName).getSim() + " " + to_string(value) + "\r\n";
    commandsToServer.push(setCommand);
    return 3;
}
