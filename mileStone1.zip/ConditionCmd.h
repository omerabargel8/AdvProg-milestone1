//
// Created by omer on 25/12/2019.
//

#ifndef EX_3_CONDITIONCMD_H
#define EX_3_CONDITIONCMD_H

#include "Command.h"
#include "VarDeclarationCmd.h"
#include "UpdateVarCmd.h"

//map of variables that updates the server(the simulator)
extern map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
extern map<string, VarDeclarationCmd> updateVarFromServer;

//map that maps between string to the matching command object
extern map<string, Command*> commandDefiner;

//this class implement the Command interface of type condition (if/while)
class ConditionCmd: public Command {
public:
    int execute(int index);
    bool conditionChecker(double val1, string operand, double val2);
};


#endif //EX_3_CONDITIONCMD_H
