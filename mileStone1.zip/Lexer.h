//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_LEXER_H
#define EX_3_LEXER_H

#include <string>
#include <vector>
using namespace std;

//this class receives a code and breaks it into an vector of strings
class Lexer {
private:
     string fileName;
public:
    Lexer(string fileName);
    vector<string> lex();
};


#endif //EX_3_LEXER_H
