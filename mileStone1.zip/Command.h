//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_COMMAND_H
#define EX_3_COMMAND_H
#include <string>
#include <iostream>
#include <queue>
#include "Lexer.h"
#include <mutex>
//queue of flight commands that we need to send to the simulator
extern queue <string> commandsToServer;
//the flag is on as long as we have not print "done"
extern bool doneFlag;
extern vector<string> lexer;
extern mutex mutexLock;
class Command {
public:
    virtual int execute(int index) = 0;
    virtual ~Command() {}
};
#endif //EX_3_COMMAND_H
