//
// Created by omer on 25/12/2019.
//

#ifndef EX_3_EXPRESSIONSDEFINER_H
#define EX_3_EXPRESSIONSDEFINER_H
#include <string>
#include "Expression.h"
#include "Interpreter.h"

class Value: public Expression {
private:
    double value;
public:
    Value(double value);
    ~Value();
    double calculate();
};
class Variable: public Expression {
private:
    string name;
    double value;
public:
    Variable(string name, double value);
    ~Variable();
    string getName();
    Value getValue();
    Variable &operator++();
    Variable &operator--();
    Variable &operator++(int);
    Variable &operator--(int);
    Variable &operator+=(double num);
    Variable &operator-=(double num);
    double calculate();
};

class BinaryOperator: public Expression {
protected:
    Expression* rightExp;
    Expression* leftExp;
public:
    BinaryOperator(Expression* exp1, Expression* exp2);
    ~BinaryOperator();
};

class UnaryOperator: public Expression {
protected:
    Expression* exp;
public:
    UnaryOperator(Expression* exp1);
    ~UnaryOperator();
};

class Plus: public BinaryOperator {
public:
    Plus(Expression* exp1, Expression* exp2);
    double calculate();
    ~Plus();
};

class Minus: public BinaryOperator {
public:
    Minus(Expression* exp1, Expression* exp2);
    double calculate();
    ~Minus();
};
class Div: public BinaryOperator {
public:
    Div(Expression* exp1, Expression* exp2);
    double calculate();
    ~Div();
};

class Mul: public BinaryOperator {
public:
    Mul(Expression* exp1, Expression* exp2);
    double calculate();
    ~Mul();
};

class UPlus: public UnaryOperator {
public:
    UPlus(Expression* exp);
    double calculate();
    ~UPlus();
};

class UMinus: public UnaryOperator {
public:
    UMinus(Expression* exp);
    double calculate();
    ~UMinus();
};
#endif //EX_3_EXPRESSIONSDEFINER_H
