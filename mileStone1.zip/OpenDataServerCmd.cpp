//
// Created by omer on 22/12/2019.
//

#include "OpenDataServerCmd.h"

//this class implement the Command interface of type OpenDataServer
//open a Server socket and wait for connection from the simulator
//the simulator sends a list of values ​​to this server 10 times a second
//the server store them in a data structure

static bool connectionDetection = false;
//this method creates thread that runs the openDataServer method.
int OpenDataServerCmd::execute(int index) {
    mapDefiner();
    this->port = i.expInterpret(lexer[index+1]);
    thread serverThread(&OpenDataServerCmd::openDataServer,this);
    while (!connectionDetection){}
    serverThread.detach();
    return 2;
}
//this method creates server socket that listening until the client(the simulator) is connected.
//when the client is connected, the server receives 10 times is second data to process.
void OpenDataServerCmd::openDataServer() {
    //create socket
    int socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if (socketfd == -1) {
        //error
        cerr << "Could not create a socket"<<endl;
    }

    //bind socket to IP address
    // we first need to create the sockaddr obj.
    sockaddr_in address; //in means IP4
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY; //give me any IP allocated for my machine
    address.sin_port = htons(port);
    //we need to convert our number
    // to a number that the network understands.

    //the actual bind command
    if (bind(socketfd, (struct sockaddr *) &address, sizeof(address)) == -1) {
        cerr<<"Could not bind the socket to an IP"<<endl;
        //return -2;
    }

    //making socket listen to the port
    if (listen(socketfd, 5) == -1) { //can also set to SOMAXCON (max connections)
        cerr<<"Error during listening command"<<endl;
        //return -3;
    } else {
        cout<<"Server is now listening ..."<<endl;
    }

    // accepting a client
    int client_socket = accept(socketfd, (struct sockaddr *)&address, (socklen_t*)&address);

    if (client_socket == -1) {
        cerr<<"Error accepting client"<<endl;
    }
    close(socketfd); //closing the listening socket
    connectionDetection = true;
    //reading from client
    char buffer[1024] = {0};
    string buffers;
    string releventLine;
    int valread = read(client_socket, buffer, 1024);
    buffers = buffer;
    int firstInstance, secondInstance;
    //while the client sends data
    while (buffer != "" && doneFlag) {
        //cout<<"buffer="<<buffer<<endl;
        //we use mutex because we want no process to use the values
        //we receives from the simulator during the update
        mutexLock.lock();
        //We want to handle one line (with 36 values) from the buffer
        //first we find the first instance of '\n' char
        firstInstance = buffers.find("\n");
        releventLine = buffers.substr(0, firstInstance);
        buffers = buffers.substr(firstInstance+ 1);
        secondInstance = -1;
        //try to find the second instance of '\n' char
        for(int p = firstInstance+1;p<1024;p++) {
            if (p == '\n' && p != '\0') {
                secondInstance = p;
                break;
            }
        }
        if (secondInstance != -1) {
            releventLine = buffers.substr(0, secondInstance);
        }
        //cout<<"first = "<<firstInstance<<endl;
        //cout<<"second= "<<secondInstance<<endl;
        //cout<<"releventLine"<<releventLine<<endl;
        updateMap(releventLine);
        mutexLock.unlock();
        valread = read(client_socket , buffer, 1024);
        buffers = buffer;
        releventLine = "";
    }
    close(client_socket);
}
//this method receives the data we received from the client
//the data is a string of values separated by- ,
//we separate the values and insert the to map of values.
//xmlVars map = <name of the variables, variables value>
void OpenDataServerCmd:: updateMap(string buffer) {
    int valsCounter = 0;
    string value = "";
    for(unsigned int j = 0; j<buffer.length();j++) {
        if (buffer[j] == ',') {
            xmlVars[xmlOrder[valsCounter]] = stod(value);
            //updated the updateVarFromServer map if there is a var that should be updated from the server (<-)
            updateVals(xmlOrder[valsCounter], stod(value));
            valsCounter++;
            value = "";
        } else {
            if(buffer[j] != '\n') {
                value += buffer[j];
            }
        }
    }
    if (value != "") {
        xmlVars[xmlOrder[valsCounter]] = stod(value);
        updateVals(xmlOrder[valsCounter], stod(value));
    }
}
//mapDefiner fills the xmlOrder map,which helps maintaining the order of the
//variables that appear in the xml file
void OpenDataServerCmd::updateVals(string sim, double value) {
    for (auto j = updateVarFromServer.begin();j != updateVarFromServer.end(); j++) {
        if(j->second.getSim() == sim) {
            j->second.updateValue(value);
        }
    }
}
//this method initialize the xmlOrder map,
//key = position in the row of values, value =  the path of the variable in the simulator
void OpenDataServerCmd:: mapDefiner() {
    xmlOrder[0] = "/instrumentation/airspeed-indicator/indicated-speed-kt";
    xmlOrder[1] = "/sim/time/warp";
    xmlOrder[2] = "/controls/switches/magnetos";
    xmlOrder[3] = "/instrumentation/heading-indicator/offset-deg";
    xmlOrder[4] = "/instrumentation/altimeter/indicated-altitude-ft";
    xmlOrder[5] = "/instrumentation/altimeter/pressure-alt-ft";
    xmlOrder[6] = "/instrumentation/attitude-indicator/indicated-pitch-deg";
    xmlOrder[7] = "/instrumentation/attitude-indicator/indicated-roll-deg";
    xmlOrder[8] = "/instrumentation/attitude-indicator/internal-pitch-deg";
    xmlOrder[9] = "/instrumentation/attitude-indicator/internal-roll-deg";
    xmlOrder[10] = "/instrumentation/encoder/indicated-altitude-ft";
    xmlOrder[11] = "/instrumentation/encoder/pressure-alt-ft";
    xmlOrder[12] = "/instrumentation/gps/indicated-altitude-ft";
    xmlOrder[13] = "/instrumentation/gps/indicated-ground-speed-kt";
    xmlOrder[14] = "/instrumentation/gps/indicated-vertical-speed";
    xmlOrder[15] = "/instrumentation/heading-indicator/indicated-heading-deg";
    xmlOrder[16] = "/instrumentation/magnetic-compass/indicated-heading-deg";
    xmlOrder[17] = "/instrumentation/slip-skid-ball/indicated-slip-skid";
    xmlOrder[18] = "/instrumentation/turn-indicator/indicated-turn-rate";
    xmlOrder[19] = "/instrumentation/vertical-speed-indicator/indicated-speed-fpm";
    xmlOrder[20] = "/controls/flight/aileron";
    xmlOrder[21] = "/controls/flight/elevator";
    xmlOrder[22] = "/controls/flight/rudder";
    xmlOrder[23] = "/controls/flight/flaps";
    xmlOrder[24] = "/controls/engines/engine/throttle";
    xmlOrder[25] = "/controls/engines/current-engine/throttle";
    xmlOrder[26] = "/controls/switches/master-avionics";
    xmlOrder[27] = "/controls/switches/starter";
    xmlOrder[28] = "/engines/active-engine/auto-start";
    xmlOrder[29] = "/controls/flight/speedbrake";
    xmlOrder[30] = "/sim/model/c172p/brake-parking";
    xmlOrder[31] = "/controls/engines/engine/primer";
    xmlOrder[32] = "/controls/engines/current-engine/mixture";
    xmlOrder[33] = "/controls/switches/master-bat";
    xmlOrder[34] = "/controls/switches/master-alt";
    xmlOrder[35] = "/engines/engine/rpm";
}