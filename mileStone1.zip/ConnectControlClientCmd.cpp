//
// Created by omer on 22/12/2019.
//

//this class implement the Command interface of type ConnectControlClientCmd
//opens a client socket and connect the simulator as a client to send him flight commands

#include "ConnectControlClientCmd.h"
static bool connectionDetection = false;
//this method opens thread to run the openControlClient function
int ConnectControlClientCmd::execute(int index) {
    this->ip = lexer[index+1];
    this->port = i.expInterpret(lexer[index+2]);
    thread clientThread(&ConnectControlClientCmd::openControlClient,this);
    while (!connectionDetection){}
    clientThread.detach();
    return 3;
}

//thos method open socket and connect the simulator as client
void ConnectControlClientCmd::openControlClient() {
    //create socket
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        //error
        cerr << "Could not create a socket"<<endl;
        //return -1;
    }

    //We need to create a sockaddr obj to hold address of server
    sockaddr_in address; //in means IP4
    address.sin_family = AF_INET;//IP4
    address.sin_addr.s_addr = inet_addr(ip.c_str()); //the localhost address
    address.sin_port = htons(port);
    //we need to convert our number (both port & localhost)
    // to a number that the network understands.

    // Requesting a connection with the server on local host with port 8081
    int is_connect = connect(client_socket, (struct sockaddr *)&address, sizeof(address));
    if (is_connect == -1) {
        std::cerr << "Could not connect to host server"<<std::endl;
        //return -2;
    } else {
        connectionDetection = true;
        std::cout<<"Client is now connected to server" <<std::endl;
    }
    string msgToSend = "";
    while(doneFlag) {
        //sends to the simulator the commands that are on the queue
        while (!commandsToServer.empty()) {
            mutexLock.lock();
            msgToSend = commandsToServer.front();
            commandsToServer.pop();
            int is_sent = send(client_socket, msgToSend.c_str(), msgToSend.length(), 0);
            if (is_sent == -1) {
                cout << "Error sending message" << endl;
            }
            mutexLock.unlock();
        }
    }
    close(client_socket);
}