//
// Created by omer on 25/12/2019.
//
#include "ConditionCmd.h"

//this class implement the Command interface of type condition (if/while)

int ConditionCmd::execute(int index) {
    VarDeclarationCmd *var;
    int returnIndex = -1;
    //checks if the variable exist in one of the maps else update the value of var
    if (updateVarToServer.count(lexer[index+1]) > 0) {
        var = &updateVarToServer[lexer[index+1]];
    } else if (updateVarFromServer.count(lexer[index+1]) > 0){
        var = &updateVarFromServer[lexer[index+1]];
    } else {
        var->updateValue(stod(lexer[index+1]));
    }
    double val = stod(lexer[index+3]);
    //index+5 is the beginning of the loop(because of the lexer format)
    int i = index+5;
    Command *c;
    if(lexer[index] == "while") {
        //check if the condition is true
        while (conditionChecker(var->getValue(), lexer[index + 2], val)) {
            if (lexer[i] == "}") {
                returnIndex = i + 1;
                //if the current char is '{' we need to return to the beginning of the loop
                i = index + 5;
            } else {
                //input the command to c and execute
                if (commandDefiner.count(lexer[i]) > 0) {
                    c = commandDefiner[lexer[i]];
                    i += c->execute(i);
                } else {
                    c = new UpdateVarCmd();
                    i += c->execute(i);
                }
            }
        }
    } else {
        //check if the condition is true
        if (conditionChecker(var->getValue(), lexer[index + 2], val)) {
            while(lexer[i] != "}") {
                if (commandDefiner.count(lexer[i]) > 0) {
                    c = commandDefiner[lexer[i]];
                    i += c->execute(i);
                } else {
                    c = new UpdateVarCmd();
                    i += c->execute(i);
                }
            }
            returnIndex = i+1;
            }
        }
    if (returnIndex == -1) {
        int p = index;
        while(lexer[p] != "}") {
            p++;
        }
        returnIndex = p+1;
    }
    return returnIndex - index;
}
//this function receives an operator and 2 operands and checks if the condition is true
bool ConditionCmd::conditionChecker(double val1, string operand, double val2) {
    if(operand == "=="){
        return(val1 == val2);
    }
    if(operand == "!="){
        return(val1 != val2);
    }
    if(operand == "<="){
        return(val1 <= val2);
    }
    if(operand == ">="){
        return(val1 >= val2);
    }
    if(operand == ">"){
        return(val1 > val2);
    }
    if(operand == "<"){
        return(val1 < val2);
    }
    return false;
}