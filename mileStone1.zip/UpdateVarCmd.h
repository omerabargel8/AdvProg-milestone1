//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_UPDATEVARCMD_H
#define EX_3_UPDATEVARCMD_H

#include "Command.h"
#include "VarDeclarationCmd.h"
#include <map>

//map of variables that updates the server(the simulator)
extern map<string, VarDeclarationCmd> updateVarToServer;
//map of variables that updates from the server
extern map<string, VarDeclarationCmd> updateVarFromServer;

//this class implement the Command interface of type UpdateVar
class UpdateVarCmd: public Command{
private:
    string varName;
    double value;
    //we create VarDeclarationCmd object because we want to use his expInterpret methos
    VarDeclarationCmd i;
public:
    int execute(int index);
};


#endif //EX_3_UPDATEVARCMD_H
