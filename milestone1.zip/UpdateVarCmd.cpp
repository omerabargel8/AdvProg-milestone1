//
// Created by omer on 22/12/2019.
//

#include "UpdateVarCmd.h"
bool ggg = false;
int UpdateVarCmd::execute(int index) {
    ggg = true;
    //cout<<"update "<<lexer[index]<<endl;
    this->varName = lexer[index];
    //cout<<varName<<endl;
    //this->value = stod(lexer[index+2]);
    //cout<<lexer[index+1]<<endl;
    this->value = i.expInterpret(lexer[index+2]);
    updateVarToServer.at(varName).updateValue(value);
    string setCommand = "set "+ updateVarToServer.at(varName).getSim() + " " + to_string(value) + "\r\n";
    commandsToServer.push(setCommand);
    return 3;
}
