//
// Created by omer on 14/11/2019.
//

#ifndef ASS1_Interpreter_H
#define ASS1_Interpreter_H

#include "Expression.h"
#include "ExpressionsDefiner.h"
#include <map>
#include <stack>
#include <queue>
#include <string>

class Interpreter {
private:
    string expStr;
    string varExp;
    map<string, string> variables;
public:
    Expression* interpret(string expStr);
    void setVariables(string varStr);
    queue<string> splitAndAssign(string expStr);
};
#endif //ASS1_Interpreter_H