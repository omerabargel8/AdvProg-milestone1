//
// Created by omer on 22/12/2019.
//
#include <iostream>
#include <fstream>
#include "Lexer.h"
//constructor
Lexer::Lexer(string fileName) {
    this->fileName = fileName;
}
//this method opens the file that we received in the constructor,
// the file contains lines of code and returns vector of strings
vector<string> Lexer::lex() {
    string line;
    ifstream myfile;
    string command = "";
    vector<string> lexer;
    myfile.open(fileName);
    if (myfile) {
        while (getline(myfile, line)) {
            for (int i = 0; i < line.length(); i++) {
                //when we see one of the following characters, we insert the string that we saves so far to the vector.
                if (line[i] == ' ' || line[i] == ',' || line[i] == '\t') {
                    if (command != "") {
                        lexer.push_back(command);
                    }
                    command = "";
                 //when we see the character -"- we want to save all characters up to the next -"- s one string.
                } else if (line[i] == '(') {
                    if (command != "") {
                        lexer.push_back(command);
                        command = "";
                    }
                    if (line[i + 1] == '"') {
                    i += 2;
                    while (line[i] != '"') {
                        command += line[i];
                        i++;
                    }
                    lexer.push_back(command);
                    command = "";
                    i += 1;
                } else {
                        i++;
                        while(line[i] != ')') {
                            command+=line[i];
                            i++;
                        }
                        lexer.push_back(command);
                        command = "";
                    }
                } else if (line[i] == '=' && line[i-1] != '<' && line[i-1] != '>' && line[i-1] != '!' ){
                    if (line[i+1] == '=') {
                        lexer.push_back("==");
                        i+=2;
                    } else {
                        lexer.push_back("=");
                        i += 2;
                        while (i < line.length()) {
                            command += line[i];
                            i++;
                        }
                        lexer.push_back(command);
                        command = "";
                    }
                } else if (line[i] != ')'){
                    command += line[i];
                }

            }
            //when we finishing reading the line, and our string is not empty we need to insert the string to the vector.
            if (command != "") {
                lexer.push_back(command);
                command = "";
            }
        }
        myfile.close();
    } else {
        cout << "Unable to open file";
    }
    return lexer;
}