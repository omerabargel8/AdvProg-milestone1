//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_CONNECTCONTROLCLIENTCMD_H
#define EX_3_CONNECTCONTROLCLIENTCMD_H
#include "Command.h"
#include "VarDeclarationCmd.h"
#include <thread>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstring>
using namespace std;
class ConnectControlClientCmd: public Command {
private:
    string ip;
    int port;
    VarDeclarationCmd i;
public:
    int execute(int index);
    void openControlClient();
};


#endif //EX_3_CONNECTCONTROLCLIENTCMD_H
