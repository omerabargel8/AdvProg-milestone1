//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_SLEEPCMD_H
#define EX_3_SLEEPCMD_H

#include "Command.h"
#include <unistd.h>
#include "VarDeclarationCmd.h"
class SleepCmd: public Command {
public:
    int execute(int index);
};


#endif //EX_3_SLEEPCMD_H
