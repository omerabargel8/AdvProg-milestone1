#include "OpenDataServerCmd.h"
#include "ConnectControlClientCmd.h"
#include "VarDeclarationCmd.h"
#include "UpdateVarCmd.h"
#include "SleepCmd.h"
#include "ConditionCmd.h"
#include "Command.h"
#include "PrintCmd.h"
map<string, VarDeclarationCmd> updateVarToServer;
map<string, VarDeclarationCmd> updateVarFromServer;
map<string, Command*> commandDefiner;
map<string,double> values;
queue <string> commandsToServer;
bool doneFlag;
vector<string> lexer;
void defineCommandDefiner();
mutex mutexLock;
void parser();
int main(int argc, char *argv[]) {
    if(argc == 1) {
        cout<<"No arguments were passed"<<endl;
    } else {
        doneFlag = true;
        Lexer flightInstructionsReader = Lexer(argv[1]);
        lexer = flightInstructionsReader.lex();
        parser();
    }
    return 0;
}
void parser() {
    defineCommandDefiner();
    int i = 0;
    int flag = 0;
    while (i < lexer.size()) {
        if (commandDefiner.count(lexer[i]) > 0) {
            Command *c = commandDefiner[lexer[i]];
            i += c->execute(i);
        } else{
            Command *c = new UpdateVarCmd();
            i += c->execute(i);
        }
    }
}
void defineCommandDefiner() {
    commandDefiner["openDataServer"] = new OpenDataServerCmd();
    commandDefiner["connectControlClient"] = new ConnectControlClientCmd();
    commandDefiner["Print"] = new PrintCmd();
    commandDefiner["var"] = new VarDeclarationCmd();
    commandDefiner["Sleep"] = new SleepCmd();
    commandDefiner["while"] = new ConditionCmd();
    commandDefiner["if"] = new ConditionCmd();
}