//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_OPENDATASERVERCMD_H
#define EX_3_OPENDATASERVERCMD_H
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <thread>
#include <map>
#include <unordered_map>
#include <string>
#include "Command.h"
#include "VarDeclarationCmd.h"
extern map<string, VarDeclarationCmd> updateVarToServer;
extern map<string, VarDeclarationCmd> updateVarFromServer;
using namespace std;
class OpenDataServerCmd: public Command {
private:
    int port;
    unordered_map <string,double> xmlVars;
    map <int, string> xmlOrder;
public:
    void openDataServer();
    int execute(int index);
    void mapDefiner();
    void updateMap(string buffer);
    void updateVals(string sim, double value);
};


#endif //EX_3_OPENDATASERVERCMD_H
