//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_UPDATEVARCMD_H
#define EX_3_UPDATEVARCMD_H

#include "Command.h"
#include "VarDeclarationCmd.h"
#include <map>
extern map<string, VarDeclarationCmd> updateVarToServer;
extern map<string, VarDeclarationCmd> updateVarFromServer;
class UpdateVarCmd: public Command{
private:
    string varName;
    double value;
    //we create VarDeclarationCmd object because we want to use his expInterpret methos
    VarDeclarationCmd i;
public:
    int execute(int index);
};


#endif //EX_3_UPDATEVARCMD_H
