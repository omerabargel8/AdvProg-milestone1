//
// Created by omer on 22/12/2019.
//

#include "SleepCmd.h"
#include <thread>
int SleepCmd::execute(int index) {
    //cout<<"sleep for "<<lexer[index+1]<<endl;
    VarDeclarationCmd i;
    this_thread::sleep_for(chrono::milliseconds((int)i.expInterpret(lexer[index+1])));
    return 2;
}