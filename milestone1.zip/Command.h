//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_COMMAND_H
#define EX_3_COMMAND_H
#include <string>
#include <iostream>
#include <queue>
#include "Lexer.h"
#include <mutex>
//#include "ExpInterpreter.h"
extern queue <string> commandsToServer;
extern bool doneFlag;
extern vector<string> lexer;
extern mutex mutexLock;
class Command {
public:
    virtual int execute(int index) = 0;
};
#endif //EX_3_COMMAND_H
