//
// Created by omer on 25/12/2019.
//

#include "ConditionCmd.h"
int ConditionCmd::execute(int index) {
    //cout<<"while"<<endl;
    //cout<<"<< "<<updateVarFromServer["rpm"].getValue()<<endl;
    VarDeclarationCmd *var;
    int returnIndex;
    if (updateVarToServer.count(lexer[index+1]) > 0) {
        var = &updateVarToServer[lexer[index+1]];
    } else if (updateVarFromServer.count(lexer[index+1]) > 0){
        var = &updateVarFromServer[lexer[index+1]];
    } else {
        var->updateValue(stod(lexer[index+1]));
    }
    double val = stod(lexer[index+3]);
    int i = index+5;
    Command *c;
    if(lexer[index] == "while") {
        while (conditionChecker(var->getValue(), lexer[index + 2], val)) {
            //printMap();
            //cout<<"** "<<updateVarFromServer["rpm"].getValue()<<endl;
            //cout<<"&& "<<updateVarFromServer["heading"].getValue()<<endl;
            if (lexer[i] == "}") {
                returnIndex = i + 1;
                i = index + 5;
            } else {
                if (commandDefiner.count(lexer[i]) > 0) {
                    c = commandDefiner[lexer[i]];
                    i += c->execute(i);
                } else {
                    c = new UpdateVarCmd();
                    i += c->execute(i);
                }
            }
        }
    } else {
        string b = lexer[index+2];
        double v = var->getValue();
        cout<<val<<endl;
        if (conditionChecker(var->getValue(), lexer[index + 2], val)) {
            //printMap();
            //cout<<"** "<<updateVarFromServer["rpm"].getValue()<<endl;
            //cout<<"&& "<<updateVarFromServer["heading"].getValue()<<endl;
            while(lexer[i] != "}") {
                if (commandDefiner.count(lexer[i]) > 0) {
                    c = commandDefiner[lexer[i]];
                    i += c->execute(i);
                } else {
                    c = new UpdateVarCmd();
                    i += c->execute(i);
                }
            }
            returnIndex = i+1;
            }
        }
    return returnIndex - index;
}
bool ConditionCmd::conditionChecker(double val1, string operand, double val2) {
    if(operand == "=="){
        return(val1 == val2);
    }
    if(operand == "!="){
        return(val1 != val2);
    }
    if(operand == "<="){
        if (val1 <= val2) {
            return true;
        } else {
            return false;
        }
    }
    if(operand == ">="){
        return(val1 >= val2);
    }
    if(operand == ">"){
        return(val1 > val2);
    }
    if(operand == "<"){
        return(val1 < val2);
    }
}