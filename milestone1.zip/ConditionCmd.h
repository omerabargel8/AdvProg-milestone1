//
// Created by omer on 25/12/2019.
//

#ifndef EX_3_CONDITIONCMD_H
#define EX_3_CONDITIONCMD_H

#include "Command.h"
#include "VarDeclarationCmd.h"
#include "UpdateVarCmd.h"
extern map<string, VarDeclarationCmd> updateVarToServer;
extern map<string, VarDeclarationCmd> updateVarFromServer;
extern map<string, Command*> commandDefiner;

class ConditionCmd: public Command {
public:
    int execute(int index);
    bool conditionChecker(double val1, string operand, double val2);
};


#endif //EX_3_CONDITIONCMD_H
