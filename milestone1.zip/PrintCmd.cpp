//
// Created by omer on 30/12/2019.
//
#include "PrintCmd.h"
int PrintCmd::execute(int index) {
    //cout<<"print"<<endl;
    VarDeclarationCmd var;
    if (updateVarToServer.count(lexer[index+1]) > 0) {
        cout<<updateVarToServer[lexer[index+1]].getValue()<<endl;
    } else if (updateVarFromServer.count(lexer[index+1])>0){
        cout<<updateVarFromServer[lexer[index+1]].getValue()<<endl;
    } else {
        cout<<lexer[index+1] << endl;
    }
    return 2;
}
