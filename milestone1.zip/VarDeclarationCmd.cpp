//
// Created by omer on 22/12/2019.
//
#include "VarDeclarationCmd.h"
extern map<string, VarDeclarationCmd> updateVarToServer;
extern map<string, VarDeclarationCmd> updateVarFromServer;
int VarDeclarationCmd::execute(int index) {
    //cout<<"vardeclaration"<<endl;
    this->varName = lexer[index+1];
    if (lexer[index+2] == "->") {
        this->simPointer = lexer[index+4];
        updateVarToServer.emplace(varName, *this);
    } else if (lexer[index+2] == "<-"){
        this->simPointer = lexer[index+4];
        updateVarFromServer.emplace(varName, *this);
    } else {
        //this->value = stod(lexer[index+3]);
        this->value = expInterpret(lexer[index+3]);
        this->simPointer = "";
        updateVarFromServer.emplace(varName, *this);
        return 4;
    }
    return 5;
}
void VarDeclarationCmd::updateValue(double val) {
    this->value = val;
}
string VarDeclarationCmd::getSim() {
    return this->simPointer;
}

double VarDeclarationCmd::getValue() {
    return this->value;
}
double VarDeclarationCmd::expInterpret(string exp) {
    Interpreter i;
    string exp1 = expLexer(exp);
    Expression *ex =  i.interpret(exp1);
    return ex->calculate();
}
string VarDeclarationCmd::expLexer(string exp) {
    string holder = "";
    string expression = "";
    string value = "";
    for (int i = 0; i<exp.length(); i++) {
        if(exp[i] == '*' || exp[i] == '/' || exp[i] == '+' || exp[i] == '-'|| exp[i] == '(' || exp[i] == ')') {
            if(holder != "") {
                if (updateVarToServer.count(holder) > 0) {
                    //cout<<updateVarToServer[holder].getValue()<<endl;
                    value = to_string(updateVarToServer[holder].getValue());
                    expression += value;
                } else if (updateVarFromServer.count(holder) > 0){
                    //cout<<updateVarFromServer[holder].getValue()<<endl;
                    value = to_string(updateVarFromServer[holder].getValue());
                    expression += value;
                } else {
                    expression += holder;
                }
                holder = "";
            }
            expression += exp[i];
        } else if (exp[i] == ' '){
            if (holder != "") {
                if (updateVarToServer.count(holder) > 0) {
                    //cout<<updateVarToServer[holder].getValue()<<endl;
                    value = to_string(updateVarToServer[holder].getValue());
                    expression += value;
                } else if (updateVarFromServer.count(holder) > 0){
                    //cout<<updateVarFromServer[holder].getValue()<<endl;
                    value = to_string(updateVarFromServer[holder].getValue());
                    expression += value;
                } else {
                    expression += holder;
                }
                holder = "";
            }

        } else {
            holder += exp[i];
        }
    }
    if (holder != "") {
        if (updateVarToServer.count(holder) > 0) {
            //cout<<updateVarToServer[holder].getValue()<<endl;
            value = to_string(updateVarToServer[holder].getValue());
            expression += value;
        } else if (updateVarFromServer.count(holder) > 0){
            //cout<<updateVarFromServer[holder].getValue()<<endl;
            value = to_string(updateVarFromServer[holder].getValue());
            expression += value;
        } else {
            expression += holder;
            holder = "";
        }
    }
    return expression;
}