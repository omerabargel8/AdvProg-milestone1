//
// Created by omer on 22/12/2019.
//

#ifndef EX_3_VARDECLARATIONCMD_H
#define EX_3_VARDECLARATIONCMD_H
#include <string>
#include <map>
#include "Command.h"
#include "Interpreter.h"
using namespace std;
class VarDeclarationCmd: public Command, public error_code {
private:
    string varName;
    string simPointer;
    double value;
    Interpreter i;
public:
    int execute(int index);
    void updateValue(double val);
    string getSim();
    double getValue();
    string expLexer(string exp);
    double expInterpret(string exp);
};
#endif //EX_3_VARDECLARATIONCMD_H
