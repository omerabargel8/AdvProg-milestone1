//
// Created by omer on 25/12/2019.
//

#include "ExpressionsDefiner.h"
Value::Value(double value) {
    this->value = value;
}
Value::~Value(){}
double Value::calculate(){
    return this->value;
}
Variable::Variable(string name, double value) {
    this->name = name;
    this->value = value;
}
double Variable::calculate() {
    return  this->value;
}
string Variable::getName() {
    return  this->name;
}
Value Variable::getValue() {
    return  this->value;
}
Variable::~Variable(){}
Variable &Variable::operator++() {
    this->value = ++value;
    return *this;
}
Variable &Variable::operator--() {
    this->value = --value;
    return *this;
}
Variable &Variable::operator++(int) {
    this->value = ++value;
    return *this;
}
Variable &Variable::operator--(int) {
    this->value = --value;
    return *this;
}
Variable &Variable::operator+=(double num) {
    this->value += num;
    return *this;
}
Variable &Variable::operator-=(double num) {
    this->value -= num;
    return *this;
}
BinaryOperator::BinaryOperator(Expression* exp1, Expression* exp2) {
    this->leftExp = exp1;
    this->rightExp = exp2;
}
BinaryOperator::~BinaryOperator(){}

UnaryOperator::UnaryOperator(Expression* exp) {
    this->exp = exp;
}
UnaryOperator::~UnaryOperator(){}

Plus::Plus(Expression *exp1, Expression *exp2) : BinaryOperator(exp1, exp2) {
}
double Plus::calculate() {
    return (this->rightExp->calculate() +this->leftExp->calculate());
}
Plus::~Plus(){}
Minus::Minus(Expression *exp1, Expression *exp2) : BinaryOperator(exp1, exp2) {
}
double Minus::calculate() {
    return (this->rightExp->calculate() - this->leftExp->calculate());
}
Minus::~Minus(){}
Div::Div(Expression *exp1, Expression *exp2) : BinaryOperator(exp1, exp2) {
}
double Div::calculate() {
    if (leftExp->calculate() != 0) {
        return (this->rightExp->calculate() / this->leftExp->calculate());
    } else {
        throw "division by zero";
    }
}
Div::~Div(){}
Mul::Mul(Expression *exp1, Expression *exp2) : BinaryOperator(exp1, exp2) {
}
double Mul::calculate() {
    //check div 0
    return (this->leftExp->calculate() * this->rightExp->calculate());
}
Mul::~Mul(){}
UMinus::UMinus(Expression *exp) : UnaryOperator(exp){}
double UMinus::calculate() {
    return (-(exp->calculate()));
}
UMinus::~UMinus(){}
UPlus::UPlus(Expression *exp) : UnaryOperator(exp){}
double UPlus::calculate() {
    return (exp->calculate());
}
UPlus::~UPlus(){}