//
// Created by omer on 30/12/2019.
//

#ifndef EX_3_PRINTCMD_H
#define EX_3_PRINTCMD_H


#include "Command.h"
#include "VarDeclarationCmd.h"
extern map<string, VarDeclarationCmd> updateVarToServer;
extern map<string, VarDeclarationCmd> updateVarFromServer;

class PrintCmd: public Command {
public:
    int execute(int index);
};


#endif //EX_3_PRINTCMD_H
